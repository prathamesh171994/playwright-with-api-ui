export async function softValidate(
  page: any,
  locator: string,
  expectedValue: string,
  errors: string[],
  fieldName: string,
  endpointName: string,
  isXPath = false
) {
  try {
    const element = isXPath ? page.locator(`xpath=${locator}`) : page.locator(locator);
    const actualValue = await element.textContent();

    if ((actualValue?.trim() ?? '') !== (expectedValue ?? '')) {
      const safeEndpointName = endpointName.replace(/[^\w]/g, '_');
      const screenshotPath = `screenshots/${safeEndpointName}_${fieldName}.png`;
      await page.screenshot({ path: screenshotPath, fullPage: true });

      errors.push(`Mismatch in ${fieldName} for [${endpointName}]: Expected [${expectedValue}] but found [${actualValue?.trim()}]. Screenshot saved at ${screenshotPath}`);
    }
  } catch (error) {
    errors.push(`Error validating ${fieldName} for [${endpointName}]: ${(error as Error).message}`);
  }
}