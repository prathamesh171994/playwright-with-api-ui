import { test, expect } from '@playwright/test';
import { apiEndpoints } from './apiEndpoints';
import { softValidate } from '../../helpers/softValidation';
import * as fs from 'fs';

test.describe('Validate API response matches UI', () => {
  apiEndpoints.forEach((endpoint, index) => {
    test(`Validate API for endpoint ${index + 1}`, async ({ page }) => {
      const startTime = Date.now();
      const apiResponse = await page.request.get(endpoint, { timeout: 30000 });
      const endTime = Date.now();
      const responseTimeInMs = endTime - startTime;
      console.log(`API Response Time for [${endpoint}]: ${responseTimeInMs} ms`);
      expect(responseTimeInMs).toBeLessThanOrEqual(2000);
      expect(apiResponse.ok()).toBeTruthy();
      const apiData = await apiResponse.json();

      const fileName = `apiResponses/response_${index + 1}.json`;
      fs.mkdirSync('apiResponses', { recursive: true });
      fs.writeFileSync(fileName, JSON.stringify(apiData, null, 2));

      await page.goto('https://c360.staging.zionsbank.com/deposits');

      const errors: string[] = [];
      await softValidate(page, '#accountname', apiData.AccountName, errors, 'Account Name', endpoint);
      await softValidate(page, '#accountnumber', apiData.AccountNumber, errors, 'Account Number', endpoint);
      await softValidate(page, '#accountowner', apiData.AccountOwner, errors, 'Account Owner', endpoint);
      await softValidate(page, '#currentbalance', apiData.CurrentBalance, errors, 'Current Balance', endpoint);
      await softValidate(page, '//div[@role="columnheader" and .//div[text()="Available Balance"]]/following::div[contains(@class,"MuiDataGrid-cell")][1]', apiData.AvailableBalance, errors, 'Available Balance', endpoint, true);

      if (errors.length > 0) {
        throw new Error(`Validation failed for endpoint [${endpoint}] with API response time ${responseTimeInMs}ms:\n${errors.join('\n')}`);
      }
    });
  });
});